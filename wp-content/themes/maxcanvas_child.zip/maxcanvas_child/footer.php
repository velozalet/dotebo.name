<?php
/**
 * FOOTER
 *
 * @package maxcanvas
 */
?>

<footer class="site-footer" role="contentinfo">
</footer><!-- .site-footer -->

<?php wp_footer(); ?>
</body>
</html>
